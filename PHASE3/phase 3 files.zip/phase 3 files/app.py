import streamlit as st
import pickle
import numpy as np

model = pickle.load(open("model.pkl", "rb"))
scaler = pickle.load(open("scaler.pkl", "rb"))

st.title("Credit Risk Prediction System")

age = st.number_input("Age")
employment = st.selectbox("Employment Type", ["Salaried", "Self-Employed"])
years_emp = st.number_input("Years of Employment")
income = st.number_input("Annual Income")
savings = st.number_input("Savings Balance")
bank_balance = st.number_input("Bank Balance")
credit_score = st.number_input("Credit Score")
dti = st.number_input("Debt to Income Ratio")
loans = st.number_input("Existing Loans Count")
loan_amt = st.number_input("Loan Amount Requested")
loan_term = st.number_input("Loan Term")
missed = st.number_input("Missed Payments")
inquiries = st.number_input("Credit Inquiries")
cc_util = st.number_input("Credit Card Utilization")
residence = st.selectbox("Residence Type", ["Owned", "Rented"])
dependents = st.number_input("Dependents Count")

employment = 1 if employment == "Self-Employed" else 0
residence = 1 if residence == "Rented" else 0

if st.button("Predict"):
    data = np.array([[age, employment, years_emp, income, savings,
                      bank_balance, credit_score, dti, loans,
                      loan_amt, loan_term, missed, inquiries,
                      cc_util, residence, dependents]])

    data = scaler.transform(data)
    prediction = model.predict(data)

    if prediction[0] == 1:
        st.error("⚠️ High Risk: Likely to Default")
    else:
        st.success("✅ Low Risk: Not Likely to Default")